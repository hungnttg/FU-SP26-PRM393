const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());
//---
const db = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"a1"
});
//ket noi csdl
db.connect((err)=>{
    if(err){
        console.log("MySQL connection error: ",err);
        return;
    }
    console.log("MySQL connected");
});
//---API: GET product
app.get("/api/products",(req,res)=>{
    const sql="SELECT * FROM products";
    db.query(sql,(err,result)=>{
        if(err){
            return res.status(500).json({
                success: false,
                message:"Database error"
            });
        }
        res.json({
            success: true,
            data: result
        });
    });
});
//API: create prpduct
app.post("/api/products",(req,res)=>{
    const {name,price}=req.body;
    const sql = "INSERT INTO products(name,price) values (?,?)";
    db.query(sql,[name,price],(err,result)=>{
        if(err){
            return res.status(500).json({
                success: false
            });
        }
        res.json({
            success: true,
            message:"Product Created"
        });
    });
});
//server start
app.listen(3000,()=>{
    console.log("Server running on http://localhost:30000");
});
